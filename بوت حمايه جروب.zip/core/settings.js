module.exports = {
  maxWarnings: 2,
  allowLinks: false
};

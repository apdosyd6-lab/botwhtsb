// index.js
require('dotenv').config();
const whatsappBot = require('./bots/whatsapp');

whatsappBot.initialize();
